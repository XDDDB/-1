try{document.open();}catch(e){;}
var live800_companyID="239585";
var live800_protocol="https:";
var live800_isMobile="0";
var jsessionId = ";jsessionid=0738BF2230AA1B7FCF972B64EE483B60";
try{
if(navigator.cookieEnabled && navigator.platform !== "iPhone" && navigator.platform !== "iPad"){jsessionId = "";}
}catch(e){}
var enterurl = null;
enterurl="https%3A%2F%2Fchat32.live800.com%2Flive800%2FchatClient%2FstaticButton.js%3Fjid%3D1299642384%26companyID%3D239585%26configID%3D47422%26codeType%3Dcustom%26info%3DuserId%253d%2526name%253d%2526memo%253dv%C2%83%C3%A1o";
var isOldSkin=false;
var server_prefix_list=['https://st.live800.com/live800','https://st8.live800.com/live800','https://st10.live800.com/live800','https://st16.live800.com/live800'];
var isNeedCheckDomainBinding=false;
var globalWindowAttribute='toolbar=0,scrollbars=0,location=0,menubar=0,resizable=1,width=570,height=424';
live800_chatVersion="21";
live800_initialIcon_config="initialIconStyle=1";
jid="1299642384";
var live800_baseUrl="chat32.live800.com";
var live800_baseHtmlUrl="chat32.live800.com";
var live800_baseWebApp="/live800";
var live800_baseChatHtmlDir="/chatClient";
trustfulInfo="userId%3D%26name%3D%26memo%3D%E5%85%B6%E5%AE%83%E4%BF%A1%E6%81%AF";
live800_Language="en";
live800_configID="47422";
live800_codeType="custom";
live800_configContent="live800_float=1&live800_online=https%3A%2F%2Ficon.live800.com%2Ffileupload%2FCustomFileDownloadServer%3FcompanyID%3D239585%26fna%3D1525401160971239585&live800_offline=https%3A%2F%2Ficon.live800.com%2Ffileupload%2FCustomFileDownloadServer%3FcompanyID%3D239585%26fna%3D1525398571323239585&live800_switch=1&live800_operator=21962";
var operator={id:21962,isOnline:true};

document.write("<scr"+"ipt language=\"javascript\" src=\"https://st16.live800.com/live800/chatClient/staticButtonStatic.js\"></scr"+"ipt>");