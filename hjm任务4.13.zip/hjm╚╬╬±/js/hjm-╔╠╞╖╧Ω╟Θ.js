(function($){
	$.fn.myzoom = function(){
		var _this = $(this)
		var mask = $(this).find('.mask')
		var big = $(this).find('.big')
		var small = $(this).find('.small')
		var bigimg = $(this).find('.big img')
		var maskWidth,maskHeight,percentX,percentY
		$(this).mouseover(function(){
			mask.show()
			big.show()
			// 计算mask的宽高  小图/mask = 大图/范围
			bigimg.attr('src',small.attr('src'))
			percentX = small[0].naturalWidth / big.width()
			  percentY = small[0].naturalHeight / big.height()
			 console.log(percentX)
			 maskWidth = small.width() / percentX
		 maskHeight = small.height() / percentY
			 
			 mask.css({
				 width:maskWidth ,
				 height:maskHeight
			 })
		})
		$(this).mouseleave(function(){
			mask.hide()
			big.hide()
		})
	
		// 让网格跟随
		$(this).mousemove(function(e){
			// 鼠标位置:鼠标距离页面e.pagex - 放大镜距离页面位置 offset().left
		// 鼠标居中要减一半
		var maskx = e.pageX -_this.offset().left 
	    var masky = e.pageY -_this.offset().top 
		
		maskx = maskx - maskWidth /2
		masky = masky - maskHeight /2
		// 限制范围
		maskx = maskx < 0 ? 0 : maskx
		masky = masky < 0 ? 0 : masky ,
		maskx = maskx > ( small.width() - maskWidth)?  (small.width() - maskWidth ) : maskx
		masky = masky > ( small.height() - maskHeight )?  (small.height() - maskHeight ) : masky
		mask.css({
			left:maskx ,
			top:masky
		})
		
		// 计算大图宽高
		var bigx = maskx / small.width() * small[0].naturalWidth
		var bigy = masky / small.height() * small[0].naturalHeight
		
		
		bigimg.css({
			left: -bigx,
			top: -bigy
		})
		})
		
	}
})($)

// 点击切换图片

var index = 0
var btn = $(".atavar-btn")
var positionBox = $(".atavar-posi")
var atavarLists = $(".atavar-lists")
var imgList = positionBox.find('.liebiao-img')
var bigimg = $(".bigg")
positionBox.css({width:imgList.length*60})

imgList.click(function(){
	index = $(this).index()
changeImg()
	
})


btn.last().click(function(){
	if(index<imgList.length -1){
		index++
	}
        console.log(index)
	changeImg()
	if ((index + 5)<=imgList.length ){
		 positionBox.animate({left:-index*60},300)
	}
})
btn.first().click(function(){
	if(index>0){
		index--
	}

	changeImg()
	if (index <=(imgList.length -5)){
		 positionBox.animate({left:-index*60},300)
	}
})


	function changeImg(){
	imgList.eq(index).addClass('active')
	imgList.eq(index).siblings().removeClass('active')
	var img =imgList.eq(index).attr('src')
	bigimg.attr('src',img)
}

