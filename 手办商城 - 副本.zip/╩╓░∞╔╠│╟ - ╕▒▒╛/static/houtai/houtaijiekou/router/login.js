var login =function(req,res){

}

var register=function(req,res){

}
module.exports={
    login,
    register
}